A Sample basic HTML Template for front page of a Bike company

***Live Demo :***  https://ritwickdey.github.io/simple-bike-shopping-site/

*NOTE: Not Mobile Friendly (needs few media query to make it mobile friendly)*

> Open Souce Top Secret: This is my friend's college project which I've done :smile: :joy: :joy: :joy:
